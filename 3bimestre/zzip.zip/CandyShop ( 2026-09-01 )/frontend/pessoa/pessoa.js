const URL_API = 'http://localhost:3001';

let oQueEstaFazendo = '';
let pessoa = null;
bloquearAtributos(true);

async function procurePorChavePrimaria(chave) {
    try {
        const resposta = await fetch(`${URL_API}/pessoa/${chave}`);
        const data = await resposta.json();
        return data.sucesso ? data.pessoa : null;
    } catch (erro) {
        return null;
    }
}

async function procure() {
    const cpf_pessoa = document.getElementById("inputCPF_pessoa").value.trim().toUpperCase();
    if (!cpf_pessoa || cpf_pessoa.length != 11 ) {
        mostrarAviso("O CPF deve conter 11 caracteres.");
        return;
    }

    document.getElementById("inputCPF_pessoa").value = cpf_pessoa;
    pessoa = await procurePorChavePrimaria(cpf_pessoa);
    oQueEstaFazendo = '';
    
    if (pessoa) {
        mostrarDadosPessoa(pessoa);
        visibilidadeDosBotoes('inline', 'none', 'inline', 'inline', 'none');
        mostrarAviso("Achou no banco, pode alterar ou excluir");
    } else {
        limparAtributos();
        visibilidadeDosBotoes('inline', 'inline', 'none', 'none', 'none');
        mostrarAviso("Não achou no banco, pode inserir");
    }
}

function inserir() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');
    oQueEstaFazendo = 'inserindo';
    mostrarAviso("INSERINDO - Digite os dados da pessoa e clique em salvar");
}

function alterar() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');
    oQueEstaFazendo = 'alterando';
    mostrarAviso("ALTERANDO - Digite os novos dados e clique em salvar");
}

function excluir() {
    bloquearAtributos(true);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');
    oQueEstaFazendo = 'excluindo';
    mostrarAviso("EXCLUINDO - Clique em salvar para confirmar a exclusão");
}

async function salvar() {
    const cpf_pessoa = document.getElementById("inputCPF_pessoa").value.trim();
    const nome_pessoa = document.getElementById("inputNome_pessoa").value;
    const data_nascimento_pessoa = document.getElementById("inputData_nascimento_pessoa").value;
    const endereco_pessoa = document.getElementById("inputEndereco_pessoa").value;
    const senha_pessoa = document.getElementById("inputSenha_pessoa").value;
    const email_pessoa = document.getElementById("inputEmail_pessoa").value;


    const dadosPessoa = { cpf_pessoa, nome_pessoa,  data_nascimento_pessoa, endereco_pessoa, senha_pessoa, email_pessoa};

    try {
        if (oQueEstaFazendo === 'inserindo') {
            const resp = await fetch(`${URL_API}/pessoa`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(dadosPessoa) });
            const data = await resp.json();
            if (!data.sucesso) return mostrarAviso(data.mensagem);
            mostrarAviso("Inserido no Banco de Dados com sucesso!");
        } else if (oQueEstaFazendo === 'alterando') {
            const resp = await fetch(`${URL_API}/pessoa/${cpf_pessoa}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(dadosPessoa) });
            const data = await resp.json();
            if (!data.sucesso) return mostrarAviso(data.mensagem);
            mostrarAviso("Alterado no Banco de Dados com sucesso!");
        } else if (oQueEstaFazendo === 'excluindo') {
            const resposta = await fetch(`${URL_API}/pessoa/${cpf_pessoa}`, { method: 'DELETE' });
            const data = await resposta.json();
            if (!data.sucesso) {
                mostrarAviso(data.mensagem || "Erro ao excluir no servidor.");
                return;
            }
            mostrarAviso("Excluído do Banco de Dados!");
        }

        visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
        limparAtributos();
        document.getElementById("inputCPF_pessoa").value = "";
        listar();
    } catch (erro) {
        mostrarAviso("Erro ao efetuar operação no servidor.");
    }
}

async function listar() {
    try {
        const resposta = await fetch(`${URL_API}/pessoa/listar`);
        const data = await resposta.json();
        
        if (data.sucesso) {
            let texto = "";
            for (let linha of data.pessoas) {
                texto += `<b>[${linha.cpf_pessoa}]</b> - ${linha.nome_pessoa}</b> - ${linha.data_nascimento_pessoa}</b> - ${linha.endereco_pessoa}</b> - ${linha.senha_pessoa}</b> - ${linha.email_pessoa}<br>`;
            }
            document.getElementById("outputSaida").innerHTML = texto || "Nenhuma pessoa cadastrada.";
        } else {
            document.getElementById("outputSaida").innerHTML = `Erro no banco: ${data.mensagem}`;
        }
    } catch (erro) {
        console.error("Erro ao listar:", erro);
        document.getElementById("outputSaida").innerHTML = "Servidor offline ou erro de conexão (CORS).";
    }
}

function cancelarOperacao() {
    limparAtributos();
    bloquearAtributos(true);
    visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
    mostrarAviso("Cancelou a operação");
}

function mostrarAviso(mensagem) {
    document.getElementById("divAviso").innerHTML = mensagem;
}

function mostrarDadosPessoa(u) {
    document.getElementById("inputCPF_pessoa").value = u.cpf_pessoa;
    document.getElementById("inputNome_pessoa").value = u.nome_pessoa;
    document.getElementById("inputData_nascimento_pessoa").value = u.data_nascimento_pessoa;
    document.getElementById("inputEndereco_pessoa").value = u.endereco_pessoa;
    document.getElementById("inputSenha_pessoa").value = u.senha_pessoa;
    document.getElementById("inputEmail_pessoa").value = u.email_pessoa;

    bloquearAtributos(true);
}

function limparAtributos() {
    pessoa = null;
    oQueEstaFazendo = '';
    document.getElementById("inputNome_pessoa").value = "";
    document.getElementById("inputData_nascimento_pessoa").value = "";
    document.getElementById("inputEndereco_pessoa").value = "";
    document.getElementById("inputSenha_pessoa").value = "";
    document.getElementById("inputEmail_pessoa").value = "";

    bloquearAtributos(true);
}

function bloquearAtributos(soLeitura) {
    document.getElementById("inputCPF_pessoa").readOnly = !soLeitura;
    document.getElementById("inputNome_pessoa").readOnly = soLeitura;
    document.getElementById("inputData_nascimento_pessoa").readOnly = soLeitura;
    document.getElementById("inputEndereco_pessoa").readOnly = soLeitura;
    document.getElementById("inputSenha_pessoa").readOnly = soLeitura;
    document.getElementById("inputEmail_pessoa").readOnly = soLeitura;
}

function visibilidadeDosBotoes(btP, btI, btA, btE, btS) {
    document.getElementById("btProcure").style.display = btP;
    document.getElementById("btInserir").style.display = btI;
    document.getElementById("btAlterar").style.display = btA;
    document.getElementById("btExcluir").style.display = btE;
    document.getElementById("btSalvar").style.display = btS;
    document.getElementById("btCancelar").style.display = btS;
}