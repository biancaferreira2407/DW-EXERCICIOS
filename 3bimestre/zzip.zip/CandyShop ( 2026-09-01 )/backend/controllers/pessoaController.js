const { query } = require('../database');

// Listar todas as pessoas
exports.listarPessoa = async (req, res) => {
    try {
        const result = await query('SELECT * FROM public.pessoa ORDER BY cpf_pessoa');
        res.json({ sucesso: true, pessoas: result.rows });
    } catch (error) {
        console.error('Erro ao listar pessoas:', error);
        res.status(500).json({ sucesso: false, mensagem: 'Erro ao listar pessoas.' });
    }
};

// Obter pessoas por ID CPF
exports.obterPessoa = async (req, res) => {
    try {
        const id = req.params.id ? req.params.id.trim().toUpperCase() : '';
        if (!id || id.length > 2) {
            return res.status(400).json({ sucesso: false, mensagem: 'CPF inválido (deve ter 11 caracteres).' });
        }

        const result = await query('SELECT * FROM public.pessoa WHERE cpf_pessoa = $1', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ sucesso: false, mensagem: 'Pessoa não encontrada.' });
        }

        res.json({ sucesso: true, pessoa: result.rows[0] });
    } catch (error) {
        console.error('Erro ao obter pessoa:', error);
        res.status(500).json({ sucesso: false, mensagem: 'Erro interno do servidor.' });
    }
};

// Criar pessoa
exports.criarPessoa = async (req, res) => {
    try {
        const { cpf_pessoa, nome_pessoa, data_nascimento_pessoa, endereco_pessoa, senha_pessoa, email_pessoa } = req.body;
        const id = cpf_pessoa ? cpf_pessoa.trim() : '';

        if (!id || id.length > 2) {
            return res.status(400).json({ sucesso: false, mensagem: 'A CPF/ID deve ter 11 caracteres.' });
        }

        if (!nome_pessoa) {
            return res.status(400).json({ sucesso: false, mensagem: 'O nome é obrigatório.' });
        }

        if (!data_nascimento_pessoa) {
            return res.status(400).json({ sucesso: false, mensagem: 'A data de nascimento é obrigatória.' });
        }
        if (!endereco_pessoa) {
            return res.status(400).json({ sucesso: false, mensagem: 'O endereço é obrigatório.' });
        }
        if (!senha_pessoa) {
            return res.status(400).json({ sucesso: false, mensagem: 'A senha é obrigatório.' });
        }
        if (!email_pessoa) {
            return res.status(400).json({ sucesso: false, mensagem: 'O email é obrigatório.' });
        }

        const sql = `
            INSERT INTO public.pessoa (cpf_pessoa, nome_pessoa, data_nascimento_pessoa, endereco_pessoa, senha_pessoa, email_pessoa)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        `;

        const result = await query(sql, [id, nome_pessoa, data_nascimento_pessoa, endereco_pessoa, senha_pessoa, email_pessoa]);
        res.status(201).json({ sucesso: true, mensagem: 'Pessoa cadastrada com sucesso!', pessoa: result.rows[0] });
    } catch (error) {
        console.error('Erro ao cadastrar pessoa:', error);
        if (error.code === '23505') {
            return res.status(400).json({ sucesso: false, mensagem: 'Este cpf de pessoa já está cadastrada.' });
        }
        res.status(500).json({ sucesso: false, mensagem: 'Erro ao inserir pessoa no banco de dados.' });
    }
};

// Atualizar pessoa
exports.atualizarPessoa = async (req, res) => {
    try {
        const id = req.params.id ? req.params.id.trim() : '';
        const { nome_pessoa } = req.body;
        const { data_nascimento_pessoa } = req.body;
        const { endereco_pessoa } = req.body;
        const { senha_pessoa } = req.body;
        const { email_pessoa } = req.body;

        if (!id || id.length != 11) {
            return res.status(400).json({ sucesso: false, mensagem: 'ID inválido.' });
        }

        const sql = `
         UPDATE public.pessoa 
         SET 
           nome_pessoa = $2,
           data_nascimento_pessoa = $3,
           endereco_pessoa = $4,
           senha_pessoa = $5,
           email_pessoa = $6
         WHERE cpf_pessoa = $7
         RETURNING *
        `;

        const result = await query(sql, [nome_pessoa, data_nascimento_pessoa, endereco_pessoa, senha_pessoa, email_pessoa, id]);

        if (result.rows.length === 0) {
            return res.status(404).json({ sucesso: false, mensagem: 'Pessoa não encontrada.' });
        }

        res.json({ sucesso: true, mensagem: 'Dados da Pessoa alterados com sucesso!', pessoa: result.rows[0] });
    } catch (error) {
        console.error('Erro ao atualizar pessoa:', error);
        res.status(500).json({ sucesso: false, mensagem: 'Erro ao atualizar pessoa.' });
    }
};

// Deletar pessoa
exports.deletarPessoa = async (req, res) => {
    try {
        const id = req.params.id ? req.params.id.trim() : '';

        if (!id || id.length > 2) {
            return res.status(400).json({ sucesso: false, mensagem: 'ID inválido.' });
        }

        await query('DELETE FROM public.pessoa WHERE cpf_pessoa = $1', [id]);

        res.json({ sucesso: true, mensagem: 'pessoa excluída com sucesso!' });
    } catch (error) {
        console.error('Erro ao deletar pessoa:', error);
        if (error.code === '23503') {
            return res.status(400).json({ sucesso: false, mensagem: 'Não é possível excluir: existem funcionários associados a esta pessoa.' });
        }
        res.status(500).json({ sucesso: false, mensagem: 'Erro ao excluir pessoa.' });
    }
};