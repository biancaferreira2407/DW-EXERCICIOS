
CREATE TABLE cargo (
    id_cargo integer NOT NULL,
    nome_cargo character varying(45)
);


ALTER TABLE cargo OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 41501)
-- Name: cargo_id_cargo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cargo_id_cargo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cargo_id_cargo_seq OWNER TO postgres;

--
-- TOC entry 3451 (class 0 OID 0)
-- Dependencies: 210
-- Name: cargo_id_cargo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cargo_id_cargo_seq OWNED BY cargo.id_cargo;


--
-- TOC entry 213 (class 1259 OID 41523)
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cliente (
    pessoa_cpf_pessoa character varying(20) NOT NULL,
    renda_cliente double precision,
    data_cadastro_cliente date
);


ALTER TABLE cliente OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 41568)
-- Name: forma_pagamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE forma_pagamento (
    id_forma_pagamento integer NOT NULL,
    nome_forma_pagamento character varying(100)
);


ALTER TABLE forma_pagamento OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 41567)
-- Name: forma_pagamento_id_forma_pagamento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE forma_pagamento_id_forma_pagamento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE forma_pagamento_id_forma_pagamento_seq OWNER TO postgres;

--
-- TOC entry 3452 (class 0 OID 0)
-- Dependencies: 219
-- Name: forma_pagamento_id_forma_pagamento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE forma_pagamento_id_forma_pagamento_seq OWNED BY forma_pagamento.id_forma_pagamento;


--
-- TOC entry 212 (class 1259 OID 41508)
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE funcionario (
    pessoa_cpf_pessoa character varying(20) NOT NULL,
    salario_funcionario double precision,
    cargo_id_cargo integer,
    porcentagem_comissao_funcionario double precision
);


ALTER TABLE funcionario OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 41557)
-- Name: pagamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pagamento (
    pedido_id_pedido integer NOT NULL,
    data_pagamento timestamp without time zone,
    valor_total_pagamento double precision
);


ALTER TABLE pagamento OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 41589)
-- Name: pagamento_has_forma_pagamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pagamento_has_forma_pagamento (
    pagamento_id_pedido integer NOT NULL,
    forma_pagamento_id_forma_pagamento integer NOT NULL,
    valor_pago double precision
);


ALTER TABLE pagamento_has_forma_pagamento OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 41541)
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pedido (
    id_pedido integer NOT NULL,
    data_pedido date,
    cliente_pessoa_cpf_pessoa character varying(20),
    funcionario_pessoa_cpf_pessoa character varying(20)
);


ALTER TABLE pedido OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 41574)
-- Name: pedido_has_produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pedido_has_produto (
    produto_id_produto integer NOT NULL,
    pedido_id_pedido integer NOT NULL,
    quantidade integer,
    preco_unitario double precision
);


ALTER TABLE pedido_has_produto OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 41540)
-- Name: pedido_id_pedido_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pedido_id_pedido_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pedido_id_pedido_seq OWNER TO postgres;

--
-- TOC entry 3453 (class 0 OID 0)
-- Dependencies: 216
-- Name: pedido_id_pedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pedido_id_pedido_seq OWNED BY pedido.id_pedido;


--
-- TOC entry 209 (class 1259 OID 41496)
-- Name: pessoa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pessoa (
    cpf_pessoa character varying(20) NOT NULL,
    nome_pessoa character varying(60),
    data_nascimento_pessoa date,
    endereco_pessoa character varying(150),
    senha_pessoa character varying(50),
    email_pessoa character varying(75)
);


ALTER TABLE pessoa OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 41534)
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE produto (
    id_produto integer NOT NULL,
    nome_produto character varying(45),
    quantidade_estoque_produto integer,
    preco_unitario_produto double precision,
    id_unidade_medida character varying(2)
);


ALTER TABLE produto OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 41533)
-- Name: produto_id_produto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE produto_id_produto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE produto_id_produto_seq OWNER TO postgres;

--
-- TOC entry 3454 (class 0 OID 0)
-- Dependencies: 214
-- Name: produto_id_produto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE produto_id_produto_seq OWNED BY produto.id_produto;


--
-- TOC entry 223 (class 1259 OID 108702)
-- Name: unidade_medida; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE unidade_medida (
    id_unidade_medida character varying(2) NOT NULL,
    nome_unidade_medida character varying(30)
);


ALTER TABLE unidade_medida OWNER TO postgres;

--
-- TOC entry 3252 (class 2604 OID 41505)
-- Name: cargo id_cargo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cargo ALTER COLUMN id_cargo SET DEFAULT nextval('cargo_id_cargo_seq'::regclass);


--
-- TOC entry 3255 (class 2604 OID 41571)
-- Name: forma_pagamento id_forma_pagamento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forma_pagamento ALTER COLUMN id_forma_pagamento SET DEFAULT nextval('forma_pagamento_id_forma_pagamento_seq'::regclass);


--
-- TOC entry 3254 (class 2604 OID 66561)
-- Name: pedido id_pedido; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pedido ALTER COLUMN id_pedido SET DEFAULT nextval('pedido_id_pedido_seq'::regclass);


--
-- TOC entry 3253 (class 2604 OID 41537)
-- Name: produto id_produto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produto ALTER COLUMN id_produto SET DEFAULT nextval('produto_id_produto_seq'::regclass);


--
-- TOC entry 3432 (class 0 OID 41502)
-- Dependencies: 211
-- Data for Name: cargo; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO cargo VALUES (3, 'Caixa');
INSERT INTO cargo VALUES (4, 'Supervisor');
INSERT INTO cargo VALUES (5, 'Atendente');
INSERT INTO cargo VALUES (6, 'Repositor');
INSERT INTO cargo VALUES (7, 'Conferente');
INSERT INTO cargo VALUES (8, 'Assistente');
INSERT INTO cargo VALUES (9, 'Auxiliar');
INSERT INTO cargo VALUES (10, 'Diretor');
INSERT INTO cargo VALUES (0, 'Vendedor online');
INSERT INTO cargo VALUES (1, 'Vendedor ');
INSERT INTO cargo VALUES (111, 'cento e onze dddd');
INSERT INTO cargo VALUES (2, 'Gerente');


--
-- TOC entry 3434 (class 0 OID 41523)
-- Dependencies: 213
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO cliente VALUES ('22222222222', 3200, '2024-01-02');
INSERT INTO cliente VALUES ('33333333333', 1800, '2024-01-03');
INSERT INTO cliente VALUES ('44444444444', 4000, '2024-01-04');
INSERT INTO cliente VALUES ('55555555555', 2100, '2024-01-05');
INSERT INTO cliente VALUES ('66666666666', 3500, '2024-01-06');
INSERT INTO cliente VALUES ('77777777777', 2700, '2024-01-07');
INSERT INTO cliente VALUES ('88888888888', 5000, '2024-01-08');
INSERT INTO cliente VALUES ('99999999999', 3800, '2024-01-09');
INSERT INTO cliente VALUES ('11111111111', 2500, NULL);
INSERT INTO cliente VALUES ('10101010101', 4500, '2024-01-10');
INSERT INTO cliente VALUES ('1', 1111, '2025-10-11');
INSERT INTO cliente VALUES ('2', 22222, '2025-10-15');


--
-- TOC entry 3441 (class 0 OID 41568)
-- Dependencies: 220
-- Data for Name: forma_pagamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO forma_pagamento VALUES (1, 'Dinheiro');
INSERT INTO forma_pagamento VALUES (2, 'Cartão de Crédito');
INSERT INTO forma_pagamento VALUES (3, 'Cartão de Débito');
INSERT INTO forma_pagamento VALUES (4, 'Pix');
INSERT INTO forma_pagamento VALUES (5, 'Boleto');
INSERT INTO forma_pagamento VALUES (6, 'Vale Alimentação');
INSERT INTO forma_pagamento VALUES (7, 'Transferência Bancária');
INSERT INTO forma_pagamento VALUES (8, 'Cheque');
INSERT INTO forma_pagamento VALUES (9, 'Crédito Loja');
INSERT INTO forma_pagamento VALUES (10, 'Gift Card');


--
-- TOC entry 3433 (class 0 OID 41508)
-- Dependencies: 212
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO funcionario VALUES ('22222222222', 3000, 2, 10);
INSERT INTO funcionario VALUES ('33333333333', 1500, 3, 3);
INSERT INTO funcionario VALUES ('44444444444', 2500, 4, 6);
INSERT INTO funcionario VALUES ('55555555555', 1800, 5, 4);
INSERT INTO funcionario VALUES ('66666666666', 1600, 6, 2);
INSERT INTO funcionario VALUES ('77777777777', 2200, 7, 5);
INSERT INTO funcionario VALUES ('88888888888', 1900, 8, 3);
INSERT INTO funcionario VALUES ('99999999999', 2800, 9, 7);
INSERT INTO funcionario VALUES ('10101010101', 5000, 2, 15);
INSERT INTO funcionario VALUES ('00000000000', 0, 0, 0);
INSERT INTO funcionario VALUES ('1', 1111, 2, 1);


--
-- TOC entry 3439 (class 0 OID 41557)
-- Dependencies: 218
-- Data for Name: pagamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO pagamento VALUES (1, '2024-02-01 10:00:00', 50);
INSERT INTO pagamento VALUES (2, '2024-02-02 11:00:00', 30);
INSERT INTO pagamento VALUES (3, '2024-02-03 12:00:00', 20);
INSERT INTO pagamento VALUES (4, '2024-02-04 13:00:00', 70);
INSERT INTO pagamento VALUES (5, '2024-02-05 14:00:00', 100);
INSERT INTO pagamento VALUES (7, '2024-02-07 16:00:00', 25);
INSERT INTO pagamento VALUES (8, '2024-02-08 17:00:00', 45);
INSERT INTO pagamento VALUES (9, '2024-02-09 18:00:00', 60);
INSERT INTO pagamento VALUES (10, '2024-02-10 19:00:00', 90);
INSERT INTO pagamento VALUES (64, '2025-12-13 08:07:02.875', 9.8);
INSERT INTO pagamento VALUES (65, '2025-12-13 08:58:10.097', 13);
INSERT INTO pagamento VALUES (66, '2025-12-13 09:00:47.612', 13);
INSERT INTO pagamento VALUES (71, '2025-12-13 09:12:45.255', 13.35);
INSERT INTO pagamento VALUES (72, '2025-12-13 09:15:50.149', 13.35);


--
-- TOC entry 3443 (class 0 OID 41589)
-- Dependencies: 222
-- Data for Name: pagamento_has_forma_pagamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO pagamento_has_forma_pagamento VALUES (1, 1, 20);
INSERT INTO pagamento_has_forma_pagamento VALUES (2, 2, 30);
INSERT INTO pagamento_has_forma_pagamento VALUES (3, 3, 15);
INSERT INTO pagamento_has_forma_pagamento VALUES (4, 4, 50);
INSERT INTO pagamento_has_forma_pagamento VALUES (5, 5, 100);
INSERT INTO pagamento_has_forma_pagamento VALUES (65, 1, 8);
INSERT INTO pagamento_has_forma_pagamento VALUES (65, 4, 5);
INSERT INTO pagamento_has_forma_pagamento VALUES (66, 1, 10);
INSERT INTO pagamento_has_forma_pagamento VALUES (66, 4, 3);
INSERT INTO pagamento_has_forma_pagamento VALUES (71, 1, 13.35);
INSERT INTO pagamento_has_forma_pagamento VALUES (72, 1, 10.35);
INSERT INTO pagamento_has_forma_pagamento VALUES (72, 4, 3);


--
-- TOC entry 3438 (class 0 OID 41541)
-- Dependencies: 217
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO pedido VALUES (3, '2024-02-03', '55555555555', '66666666666');
INSERT INTO pedido VALUES (7, '2024-02-07', '44444444444', '33333333333');
INSERT INTO pedido VALUES (8, '2024-02-08', '66666666666', '55555555555');
INSERT INTO pedido VALUES (9, '2024-02-09', '88888888888', '77777777777');
INSERT INTO pedido VALUES (10, '2024-02-10', '10101010101', '99999999999');
INSERT INTO pedido VALUES (20, '2025-10-10', '33333333333', '22222222222');
INSERT INTO pedido VALUES (4, '2024-02-04', '99999999999', '88888888888');
INSERT INTO pedido VALUES (5, '2024-02-05', '33333333333', '10101010101');
INSERT INTO pedido VALUES (1, '2024-02-01', '44444444444', '22222222222');
INSERT INTO pedido VALUES (2, '2024-02-02', '11111111111', '44444444444');
INSERT INTO pedido VALUES (11, '2025-11-12', '11111111111', '00000000000');
INSERT INTO pedido VALUES (12, '2025-11-12', '1', '00000000000');
INSERT INTO pedido VALUES (13, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (14, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (15, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (16, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (17, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (18, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (19, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (21, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (22, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (23, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (24, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (25, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (26, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (27, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (28, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (29, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (30, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (31, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (32, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (33, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (34, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (35, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (36, '2025-11-13', '1', '00000000000');
INSERT INTO pedido VALUES (37, '2025-11-14', '1', '00000000000');
INSERT INTO pedido VALUES (38, '2025-11-14', '1', '00000000000');
INSERT INTO pedido VALUES (39, '2025-11-14', '1', '00000000000');
INSERT INTO pedido VALUES (40, '2025-11-14', '1', '00000000000');
INSERT INTO pedido VALUES (41, '2025-11-14', '1', '00000000000');
INSERT INTO pedido VALUES (42, '2025-11-15', '1', '00000000000');
INSERT INTO pedido VALUES (43, '2025-11-15', '1', '00000000000');
INSERT INTO pedido VALUES (44, '2025-11-15', '1', '00000000000');
INSERT INTO pedido VALUES (45, '2025-11-15', '1', '00000000000');
INSERT INTO pedido VALUES (46, '2025-11-15', '1', '00000000000');
INSERT INTO pedido VALUES (47, '2025-11-15', '1', '00000000000');
INSERT INTO pedido VALUES (48, '2025-11-16', '1', '00000000000');
INSERT INTO pedido VALUES (49, '2025-11-16', '1', '00000000000');
INSERT INTO pedido VALUES (50, '2025-11-16', '1', '00000000000');
INSERT INTO pedido VALUES (51, '2025-11-16', '1', '00000000000');
INSERT INTO pedido VALUES (52, '2025-11-16', '1', '00000000000');
INSERT INTO pedido VALUES (53, '2025-11-18', '1', '00000000000');
INSERT INTO pedido VALUES (54, '2025-11-18', '1', '00000000000');
INSERT INTO pedido VALUES (55, '2025-11-18', '1', '00000000000');
INSERT INTO pedido VALUES (56, '2025-11-20', '1', '00000000000');
INSERT INTO pedido VALUES (57, '2025-11-20', '1', '00000000000');
INSERT INTO pedido VALUES (58, '2025-11-20', '1', '00000000000');
INSERT INTO pedido VALUES (59, '2025-11-22', '1', '00000000000');
INSERT INTO pedido VALUES (60, '2025-11-23', '1', '00000000000');
INSERT INTO pedido VALUES (61, '2025-11-23', '1', '00000000000');
INSERT INTO pedido VALUES (62, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (63, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (64, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (65, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (66, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (67, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (68, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (69, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (70, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (71, '2025-12-13', '1', '00000000000');
INSERT INTO pedido VALUES (72, '2025-12-13', '1', '00000000000');


--
-- TOC entry 3442 (class 0 OID 41574)
-- Dependencies: 221
-- Data for Name: pedido_has_produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO pedido_has_produto VALUES (1, 1, 2, 5.5);
INSERT INTO pedido_has_produto VALUES (2, 2, 10, 0.5);
INSERT INTO pedido_has_produto VALUES (3, 2, 5, 1);
INSERT INTO pedido_has_produto VALUES (4, 2, 3, 3.2);
INSERT INTO pedido_has_produto VALUES (5, 5, 2, 7);
INSERT INTO pedido_has_produto VALUES (3, 1, 3, 1);
INSERT INTO pedido_has_produto VALUES (2, 3, 1, 0.5);
INSERT INTO pedido_has_produto VALUES (4, 4, 4, 4);
INSERT INTO pedido_has_produto VALUES (2, 1, 1000, 0.7);
INSERT INTO pedido_has_produto VALUES (2, 20, 1, 0.5);
INSERT INTO pedido_has_produto VALUES (1, 36, 100, 55);
INSERT INTO pedido_has_produto VALUES (3, 36, 100, 10);
INSERT INTO pedido_has_produto VALUES (8, 37, 200, 60);
INSERT INTO pedido_has_produto VALUES (10, 37, 100, 12);
INSERT INTO pedido_has_produto VALUES (2, 38, 100, 43);
INSERT INTO pedido_has_produto VALUES (7, 38, 100, 75);
INSERT INTO pedido_has_produto VALUES (6, 38, 100, 45);
INSERT INTO pedido_has_produto VALUES (4, 39, 100, 32);
INSERT INTO pedido_has_produto VALUES (5, 39, 100, 70);
INSERT INTO pedido_has_produto VALUES (6, 39, 100, 45);
INSERT INTO pedido_has_produto VALUES (1, 40, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 40, 100, 43);
INSERT INTO pedido_has_produto VALUES (3, 40, 100, 10);
INSERT INTO pedido_has_produto VALUES (4, 40, 100, 32);
INSERT INTO pedido_has_produto VALUES (5, 40, 100, 70);
INSERT INTO pedido_has_produto VALUES (1, 41, 100, 55);
INSERT INTO pedido_has_produto VALUES (3, 41, 100, 10);
INSERT INTO pedido_has_produto VALUES (4, 41, 100, 32);
INSERT INTO pedido_has_produto VALUES (10, 42, 100, 12);
INSERT INTO pedido_has_produto VALUES (2, 42, 100, 43);
INSERT INTO pedido_has_produto VALUES (3, 42, 100, 10);
INSERT INTO pedido_has_produto VALUES (1, 43, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 43, 100, 43);
INSERT INTO pedido_has_produto VALUES (3, 43, 100, 10);
INSERT INTO pedido_has_produto VALUES (2, 44, 1, 43);
INSERT INTO pedido_has_produto VALUES (3, 44, 1, 10);
INSERT INTO pedido_has_produto VALUES (3, 45, 1, 10);
INSERT INTO pedido_has_produto VALUES (2, 45, 4, 43);
INSERT INTO pedido_has_produto VALUES (3, 47, 100, 10);
INSERT INTO pedido_has_produto VALUES (2, 47, 1000, 43);
INSERT INTO pedido_has_produto VALUES (1, 48, 300, 55);
INSERT INTO pedido_has_produto VALUES (2, 48, 100, 43);
INSERT INTO pedido_has_produto VALUES (2, 49, 100, 43);
INSERT INTO pedido_has_produto VALUES (3, 49, 100, 10);
INSERT INTO pedido_has_produto VALUES (4, 49, 100, 32);
INSERT INTO pedido_has_produto VALUES (2, 50, 100, 43);
INSERT INTO pedido_has_produto VALUES (3, 50, 100, 10);
INSERT INTO pedido_has_produto VALUES (4, 50, 100, 32);
INSERT INTO pedido_has_produto VALUES (2, 51, 100, 43);
INSERT INTO pedido_has_produto VALUES (3, 51, 100, 10);
INSERT INTO pedido_has_produto VALUES (4, 51, 100, 32);
INSERT INTO pedido_has_produto VALUES (2, 52, 100, 43);
INSERT INTO pedido_has_produto VALUES (3, 52, 100, 10);
INSERT INTO pedido_has_produto VALUES (4, 52, 100, 32);
INSERT INTO pedido_has_produto VALUES (1, 53, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 53, 100, 43);
INSERT INTO pedido_has_produto VALUES (1, 54, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 54, 100, 43);
INSERT INTO pedido_has_produto VALUES (1, 55, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 55, 100, 43);
INSERT INTO pedido_has_produto VALUES (4, 56, 100, 32);
INSERT INTO pedido_has_produto VALUES (3, 56, 100, 10);
INSERT INTO pedido_has_produto VALUES (2, 57, 100, 43);
INSERT INTO pedido_has_produto VALUES (3, 57, 100, 10);
INSERT INTO pedido_has_produto VALUES (2, 58, 100, 43);
INSERT INTO pedido_has_produto VALUES (3, 58, 100, 10);
INSERT INTO pedido_has_produto VALUES (1, 59, 100, 55);
INSERT INTO pedido_has_produto VALUES (3, 59, 100, 10);
INSERT INTO pedido_has_produto VALUES (5, 60, 100, 70);
INSERT INTO pedido_has_produto VALUES (5, 61, 100, 70);
INSERT INTO pedido_has_produto VALUES (1, 62, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 62, 100, 43);
INSERT INTO pedido_has_produto VALUES (1, 63, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 63, 100, 43);
INSERT INTO pedido_has_produto VALUES (1, 64, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 64, 100, 43);
INSERT INTO pedido_has_produto VALUES (1, 65, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 65, 100, 43);
INSERT INTO pedido_has_produto VALUES (4, 65, 100, 32);
INSERT INTO pedido_has_produto VALUES (1, 66, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 66, 100, 43);
INSERT INTO pedido_has_produto VALUES (4, 66, 100, 32);
INSERT INTO pedido_has_produto VALUES (1, 67, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 67, 100, 43);
INSERT INTO pedido_has_produto VALUES (4, 67, 100, 32);
INSERT INTO pedido_has_produto VALUES (5, 67, 5, 70);
INSERT INTO pedido_has_produto VALUES (1, 68, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 68, 100, 43);
INSERT INTO pedido_has_produto VALUES (4, 68, 100, 32);
INSERT INTO pedido_has_produto VALUES (5, 68, 5, 70);
INSERT INTO pedido_has_produto VALUES (1, 69, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 69, 100, 43);
INSERT INTO pedido_has_produto VALUES (4, 69, 100, 32);
INSERT INTO pedido_has_produto VALUES (5, 69, 5, 70);
INSERT INTO pedido_has_produto VALUES (1, 70, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 70, 100, 43);
INSERT INTO pedido_has_produto VALUES (4, 70, 100, 32);
INSERT INTO pedido_has_produto VALUES (5, 70, 5, 70);
INSERT INTO pedido_has_produto VALUES (1, 71, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 71, 100, 43);
INSERT INTO pedido_has_produto VALUES (4, 71, 100, 32);
INSERT INTO pedido_has_produto VALUES (5, 71, 5, 70);
INSERT INTO pedido_has_produto VALUES (1, 72, 100, 55);
INSERT INTO pedido_has_produto VALUES (2, 72, 100, 43);
INSERT INTO pedido_has_produto VALUES (4, 72, 100, 32);
INSERT INTO pedido_has_produto VALUES (5, 72, 5, 70);


--
-- TOC entry 3430 (class 0 OID 41496)
-- Dependencies: 209
-- Data for Name: pessoa; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO pessoa VALUES ('10101010101', 'Juliana Dias ssss', '1989-10-25', 'lins, 352 ssss', '1111', 'juliana@email.comm');
INSERT INTO pessoa VALUES ('44444444444', 'Ana Lima', '1995-04-25', 'Alameda do medo, 4534 apto 13', '.123456', 'ana@email.com');
INSERT INTO pessoa VALUES ('55555555555', 'Lucas Mendes', '1988-05-30', 'Rua sexta_feira, 13 _ apto 666', '.123456', 'lucas@email.com');
INSERT INTO pessoa VALUES ('66666666666', 'Fernanda Costa', '1993-06-05', 'muito longe, 243', '.123456', 'fernanda@email.com');
INSERT INTO pessoa VALUES ('77777777777', 'Ricardo Alves', '1987-07-10', 'far far faraway, 34', '.123456', 'ricardo@email.com');
INSERT INTO pessoa VALUES ('88888888888', 'Patrícia Gomes', '1994-08-15', 'acolá, 54', '.123456', 'patricia@email.com');
INSERT INTO pessoa VALUES ('99999999999', 'Marcos Rocha', '1991-09-20', 'kaxa prego _ ilha de itaparica', '.123456', 'marcos@email.com');
INSERT INTO pessoa VALUES ('22222222222', 'Maria Souza', '1985-02-15', 'lá longe, 1234', '.123456', 'maria@email.com');
INSERT INTO pessoa VALUES ('1', 'Berola', '2025-10-16', 'Lá onde Judas perdeu a unha, s/n', '12345', 'berola@gmail.com');
INSERT INTO pessoa VALUES ('00000000000', 'online', '1900-01-01', 'Loja', 'abc123', 'online@gmail.com');
INSERT INTO pessoa VALUES ('33333333333', 'Carlos Pereira', '1992-03-20', 'Rua que Judas perdeu as botas, 234', '123456x', 'carlos@email.com');
INSERT INTO pessoa VALUES ('11111111111', 'João Silva', '2025-01-01', 'algum lugar', '123456x', 'joao@email.com');
INSERT INTO pessoa VALUES ('2', 'dois', '2025-10-07', 'Rua das Magnólias', '123456x', 'dois@email.com');


--
-- TOC entry 3436 (class 0 OID 41534)
-- Dependencies: 215
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO produto VALUES (8, 'Pão de Mel', 40, 60, NULL);
INSERT INTO produto VALUES (9, 'Doce de Leite', 30, 85, NULL);
INSERT INTO produto VALUES (4, 'Biscoito', 80, 32, NULL);
INSERT INTO produto VALUES (1, 'Chocolate', 100, 55, NULL);
INSERT INTO produto VALUES (3, 'Pirulito', 150, 10, NULL);
INSERT INTO produto VALUES (5, 'Refrigerante', 50, 70, NULL);
INSERT INTO produto VALUES (7, 'Chiclete', 300, 75, NULL);
INSERT INTO produto VALUES (10, 'Sorvete', 20, 12, NULL);
INSERT INTO produto VALUES (2, 'Bala', 200, 43, NULL);
INSERT INTO produto VALUES (6, 'Suco', 60, 45, NULL);
INSERT INTO produto VALUES (50, 'cinquenta', 50, 50, NULL);


--
-- TOC entry 3444 (class 0 OID 108702)
-- Dependencies: 223
-- Data for Name: unidade_medida; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3455 (class 0 OID 0)
-- Dependencies: 210
-- Name: cargo_id_cargo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cargo_id_cargo_seq', 10, true);


--
-- TOC entry 3456 (class 0 OID 0)
-- Dependencies: 219
-- Name: forma_pagamento_id_forma_pagamento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('forma_pagamento_id_forma_pagamento_seq', 10, true);


--
-- TOC entry 3457 (class 0 OID 0)
-- Dependencies: 216
-- Name: pedido_id_pedido_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pedido_id_pedido_seq', 72, true);


--
-- TOC entry 3458 (class 0 OID 0)
-- Dependencies: 214
-- Name: produto_id_produto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('produto_id_produto_seq', 10, true);


--
-- TOC entry 3261 (class 2606 OID 41507)
-- Name: cargo cargo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cargo
    ADD CONSTRAINT cargo_pkey PRIMARY KEY (id_cargo);


--
-- TOC entry 3265 (class 2606 OID 41527)
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (pessoa_cpf_pessoa);


--
-- TOC entry 3273 (class 2606 OID 41573)
-- Name: forma_pagamento forma_pagamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forma_pagamento
    ADD CONSTRAINT forma_pagamento_pkey PRIMARY KEY (id_forma_pagamento);


--
-- TOC entry 3263 (class 2606 OID 41512)
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (pessoa_cpf_pessoa);


--
-- TOC entry 3277 (class 2606 OID 41593)
-- Name: pagamento_has_forma_pagamento pagamento_has_forma_pagamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pagamento_has_forma_pagamento
    ADD CONSTRAINT pagamento_has_forma_pagamento_pkey PRIMARY KEY (pagamento_id_pedido, forma_pagamento_id_forma_pagamento);


--
-- TOC entry 3271 (class 2606 OID 41561)
-- Name: pagamento pagamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pagamento
    ADD CONSTRAINT pagamento_pkey PRIMARY KEY (pedido_id_pedido);


--
-- TOC entry 3275 (class 2606 OID 41578)
-- Name: pedido_has_produto pedido_has_produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pedido_has_produto
    ADD CONSTRAINT pedido_has_produto_pkey PRIMARY KEY (produto_id_produto, pedido_id_pedido);


--
-- TOC entry 3269 (class 2606 OID 41546)
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (id_pedido);


--
-- TOC entry 3257 (class 2606 OID 41500)
-- Name: pessoa pessoa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pessoa
    ADD CONSTRAINT pessoa_pkey PRIMARY KEY (cpf_pessoa);


--
-- TOC entry 3259 (class 2606 OID 42000)
-- Name: pessoa pessoa_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pessoa
    ADD CONSTRAINT pessoa_unique UNIQUE (email_pessoa);


--
-- TOC entry 3267 (class 2606 OID 41539)
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (id_produto);


--
-- TOC entry 3279 (class 2606 OID 108706)
-- Name: unidade_medida unidade_medida_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY unidade_medida
    ADD CONSTRAINT unidade_medida_pk PRIMARY KEY (id_unidade_medida);


--
-- TOC entry 3282 (class 2606 OID 41528)
-- Name: cliente cliente_pessoa_cpf_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cliente
    ADD CONSTRAINT cliente_pessoa_cpf_pessoa_fkey FOREIGN KEY (pessoa_cpf_pessoa) REFERENCES pessoa(cpf_pessoa);


--
-- TOC entry 3281 (class 2606 OID 41518)
-- Name: funcionario funcionario_cargo_id_cargo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY funcionario
    ADD CONSTRAINT funcionario_cargo_id_cargo_fkey FOREIGN KEY (cargo_id_cargo) REFERENCES cargo(id_cargo);


--
-- TOC entry 3280 (class 2606 OID 41513)
-- Name: funcionario funcionario_pessoa_cpf_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY funcionario
    ADD CONSTRAINT funcionario_pessoa_cpf_pessoa_fkey FOREIGN KEY (pessoa_cpf_pessoa) REFERENCES pessoa(cpf_pessoa);


--
-- TOC entry 3290 (class 2606 OID 41599)
-- Name: pagamento_has_forma_pagamento pagamento_has_forma_pagamento_forma_pagamento_id_forma_pag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pagamento_has_forma_pagamento
    ADD CONSTRAINT pagamento_has_forma_pagamento_forma_pagamento_id_forma_pag_fkey FOREIGN KEY (forma_pagamento_id_forma_pagamento) REFERENCES forma_pagamento(id_forma_pagamento);


--
-- TOC entry 3289 (class 2606 OID 41594)
-- Name: pagamento_has_forma_pagamento pagamento_has_forma_pagamento_pagamento_id_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pagamento_has_forma_pagamento
    ADD CONSTRAINT pagamento_has_forma_pagamento_pagamento_id_pedido_fkey FOREIGN KEY (pagamento_id_pedido) REFERENCES pagamento(pedido_id_pedido);


--
-- TOC entry 3286 (class 2606 OID 41562)
-- Name: pagamento pagamento_pedido_id_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pagamento
    ADD CONSTRAINT pagamento_pedido_id_pedido_fkey FOREIGN KEY (pedido_id_pedido) REFERENCES pedido(id_pedido);


--
-- TOC entry 3284 (class 2606 OID 41547)
-- Name: pedido pedido_cliente_pessoa_cpf_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pedido
    ADD CONSTRAINT pedido_cliente_pessoa_cpf_pessoa_fkey FOREIGN KEY (cliente_pessoa_cpf_pessoa) REFERENCES cliente(pessoa_cpf_pessoa);


--
-- TOC entry 3285 (class 2606 OID 41552)
-- Name: pedido pedido_funcionario_pessoa_cpf_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pedido
    ADD CONSTRAINT pedido_funcionario_pessoa_cpf_pessoa_fkey FOREIGN KEY (funcionario_pessoa_cpf_pessoa) REFERENCES funcionario(pessoa_cpf_pessoa);


--
-- TOC entry 3288 (class 2606 OID 41584)
-- Name: pedido_has_produto pedido_has_produto_pedido_id_pedido_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pedido_has_produto
    ADD CONSTRAINT pedido_has_produto_pedido_id_pedido_fkey FOREIGN KEY (pedido_id_pedido) REFERENCES pedido(id_pedido);


--
-- TOC entry 3287 (class 2606 OID 41579)
-- Name: pedido_has_produto pedido_has_produto_produto_id_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pedido_has_produto
    ADD CONSTRAINT pedido_has_produto_produto_id_produto_fkey FOREIGN KEY (produto_id_produto) REFERENCES produto(id_produto);


--
-- TOC entry 3283 (class 2606 OID 108707)
-- Name: produto produto_unidade_medida_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produto
    ADD CONSTRAINT produto_unidade_medida_fk FOREIGN KEY (id_unidade_medida) REFERENCES unidade_medida(id_unidade_medida);


